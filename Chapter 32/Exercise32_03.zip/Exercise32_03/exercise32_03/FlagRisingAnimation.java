/* John Macdonald
 * Jan 31, 2023
 * 
 * I modified this code to use a thread to
 * animate the raising of a flag instead of
 * a timer.
 * */

package exercise32_03;

import javafx.animation.PathTransition; 
import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;

public class FlagRisingAnimation extends Application implements Runnable {

	ImageView imageView = new ImageView("image/us.gif");
	
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// Create a pane
		Pane pane = new Pane();
	
//		// Add an image view and add it to pane
		pane.getChildren().add(imageView);
//
//
//		// Create a path transition
//		PathTransition pt = new PathTransition(Duration.millis(10000),
//						new Line(100, 200, 100, 0), imageView); pt.setCycleCount(5);
//		pt.play(); // Start animation
		
		
		
		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 250, 200); 
		primaryStage.setTitle("FlagRisingAnimation"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
		
		Thread rise = new Thread(new Runnable() {

			@Override
			public void run() {
				PathTransition pt = new PathTransition(Duration.millis(10000),
					new Line(100, 200, 100, 0), imageView); pt.setCycleCount(5);
				pt.play();
				
			}});
		rise.start();
		
	}//start method end
	
	public static void main(String[] args) {
		Application.launch(args);
	}//main method end

	@Override
	public void run() {}
	
}//FlagRisingAnimation end
