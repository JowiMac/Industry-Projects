/* John Macdonald
 * Feb. 6, 2023
 * 
 * This program displays a window to calculate
 * money over time, using text fields and a menu
 * */

package exercise31_17;

  import javafx.application.Application;
  import javafx.geometry.Pos;
  import javafx.scene.Scene;
  import javafx.scene.control.Button;
  import javafx.scene.control.Label;
  import javafx.scene.control.Menu;
  import javafx.scene.control.MenuBar;
  import javafx.scene.control.MenuItem;
  import javafx.scene.control.TextField;
  import javafx.scene.layout.HBox;
  import javafx.scene.layout.VBox;
  import javafx.scene.layout.GridPane;
  import javafx.stage.Stage;



public class Exercise31_17 extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		
		MenuBar menuBar = new MenuBar();
		
		Menu menuOperation = new Menu("Operation");
		menuBar.getMenus().add(menuOperation);
		
		MenuItem menuCalculate = new MenuItem("Calculate");
		MenuItem menuExit = new MenuItem("Exit");
		
		menuOperation.getItems().addAll(menuCalculate, menuExit);
		
		menuBar.snappedTopInset();
		
		GridPane grid = new GridPane();
		GridPane pane = new GridPane();
		pane.setAlignment(Pos.CENTER);
		
		pane.setHgap(5);
		pane.setVgap(5);
		
		TextField Amount = new TextField();
		pane.add(new Label("Investment Amount: "), 0, 0);
		pane.add(Amount, 1, 0);
		
		
		TextField numYear = new TextField();
		pane.add(new Label("Number of Years: "), 0, 1);
		pane.add(numYear, 1, 1);
		
		TextField Annual = new TextField();
		pane.add(new Label("Annual Interest Rate: "), 0, 2);
		pane.add(Annual, 1, 2);
		
		TextField Future = new TextField();
		Future.setEditable(false);
		pane.add(new Label("Future Value: "), 0, 3);
		pane.add(Future, 1, 3);
		
		Button btCal = new Button("Caclulate");
		pane.add(btCal, 1, 4);
		
		menuCalculate.setOnAction(e -> {
			int amount = Integer.parseInt(Amount.getText());
			int years = Integer.parseInt(numYear.getText());
			double annual = Double.parseDouble(Annual.getText());

			String result = Calculate(amount, years, annual);
				Future.setText("$" + result);
		});
		
		btCal.setOnAction(e -> {
			int amount = Integer.parseInt(Amount.getText());
			int years = Integer.parseInt(numYear.getText());
			double annual = Double.parseDouble(Annual.getText());
			
			String result = Calculate(amount, years, annual);
				Future.setText("$" + result);
		});
		
		menuExit.setOnAction(e -> System.exit(0));
		
		
		
		grid.add(menuBar, 0, 0);
		grid.add(pane, 0, 1);
		
		Scene scene = new Scene(grid);
		primaryStage.setTitle("Exercise 31-17");
		primaryStage.setScene(scene);
		primaryStage.show();

	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	public String Calculate(int amount, int years, double annual) {
		
		double monthlyInterestRate = annual / 1200;
		
		double futureValue = Math.round(amount * Math.pow((1 + monthlyInterestRate),(years*12)) * 100.0)/100.0;
		
		String futureVal = String.valueOf(futureValue);

		return futureVal;
		}

}
