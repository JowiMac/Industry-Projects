/* John Macdonald, August 22, 2022 10:37AM

This code is separate from the Probability files.
This was an old code project used for comparison
to my new project that uses multiple files and
methods to complete its tasks.

This program will roll two dice that are specified
by the user. It will then calculate a total of the
two dice rolled and display a probability in percentage
of how often that the total can be rolled.
*/
package project;

import java.util.Scanner;
import java.lang.Math;

class probProj {
	public static void main(String[] args) {
		
		for(int t = 0; t < 1 && t > -1;){
			
			Scanner input = new Scanner(System.in);
			
			System.out.println("Enter these numbers to compare dice\n1 : d2, 2 : d4,  3 : d6,\n4 : d8, 5 : d10, 6 : d12\n");
			
			int[] Dice = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
						
			//int dOne is user defined
			System.out.print("What is your first die? ");
			int dOne = input.nextInt();
			System.out.println("You chose a d" + (dOne * 2) + " die.");
			
			//Invalid input
			if(dOne > 6 || dOne < 1){
				System.out.print("That is not a valid input. Try again.");
				System.exit(0);
			}//if statement end
			
			//dieOne array defined
			int[] dieOne = new int[(dOne * 2)];
			for (int i = 0; i < dieOne.length; i++){
				dieOne[i] = Dice[i];
				System.out.print(dieOne[i] + ", ");
			}//for loop end
			
			
			System.out.print("\n \n");
			
			
			//int dTwo is user defined
			System.out.print("What is your second die to compare? ");
			int dTwo = input.nextInt();
			System.out.println("You chose a d" + (dTwo * 2) + " die.");
			
			//Invalid input
			if(dTwo > 6 || dTwo < 1){
				System.out.print("That is not a valid input. Try again.");
				System.exit(0);
			}//if statement end
			
			//dieTwo array defined
			int[] dieTwo = new int[(dTwo * 2)];
			for (int i = 0; i < dieTwo.length; i++){
				dieTwo[i] = Dice[i];
				System.out.print(dieTwo[i] + ", ");
			}//for loop end
			
			
			System.out.print("\n \n");
			
			
			//rolling the dice
			int randoOne = (int)(Math.random() * (dOne * 2));
			int randoTwo = (int)(Math.random() * (dTwo * 2));
			
			int rollOne = dieOne[randoOne];
			System.out.println("This is the roll for die number one: " + rollOne);
			int rollTwo = dieTwo[randoTwo];
			System.out.println("This is the roll for die number two: " + rollTwo);
						
			
			//total variable defined
			int total = rollOne + rollTwo;
			System.out.println("This is the total of the rolled dice: " + total);
			
						
			System.out.println();
			
			
			//max output of dice rolled defined
			int dmax = (dOne * 2) + (dTwo * 2);
			System.out.println("This is the possible max roll for the dice " + dmax);
			
			//method is run for percentage
			double percentage = probperc(dieOne, dieTwo, total, dmax) * 100;
			System.out.println("This is the probability of this number being rolled: " + (int)percentage + "%");
			
			//Try again?
			System.out.println("\nWould you like to calculate more probabilities?");
			System.out.print("Enter 0 for yes and any other number for no ");
			t = input.nextInt();
			if (t >= 1 || t <= -1){
				System.out.println("\nThank you for trying out my probability calculator.");
			}//if end
			System.out.println();
			
		}//for loop end
	}//main method end
	
	//method probperc defined
	public static double probperc(int[] dieOne, int[] dieTwo, int total, int dmax){
		
		//variable counted in for loops
		double perctot = 0;
				
		//determine percentages
		for (int i = 0; i < dieOne.length; i++){
			for (int j = 0; j < dieTwo.length; j++){
				if(total == dieOne[i] + dieTwo[j]){
					perctot++;
				}//if statement end
			}//nested for loop end
		}//for loop end
		
		//Times rolled total can be rolled out of max number
		System.out.println("The total (" + total + ") can be rolled " + (int)perctot + " times out of " + dmax);
				
		//percentage calculated
		double perc = perctot / dmax;
		
		return perc;
	}//probability percent method end
	
}//class end