/* John Macdonald, February 9, 2023
 * 
 * This program determines probability of two different
 * objects and puts the comparison on a bar chart
 */


package project;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javafx.scene.chart.*;
import javafx.scene.chart.XYChart.Series;
import javafx.application.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.*;
import javafx.scene.shape.*;
import javafx.collections.*;

public class ProbabilityTest extends Application {
	public static void main(String[] args) {
		
		launch(args);
		
	}//Method main end

	@SuppressWarnings("unchecked")
	@Override
	public void start(Stage primaryStage) throws Exception {
		
	//TabPane and scene
		TabPane tabPane = new TabPane();
		Tab tab1 = new Tab("Calculate");
		Tab tab2 = new Tab("Graph");
		
		Pane pane = new Pane();
		pane.setPadding(new Insets(5, 5, 5, 5));
		
		Pane pane2 = new Pane();
		pane2.setPadding(new Insets(5, 5, 5, 5));
		
		tab1.setContent(pane);
		tab2.setContent(pane2);
		
		tabPane.getTabs().addAll(tab1, tab2);
		
		Scene scene = new Scene(tabPane , 517, 425);
		
	//BarChart
		CategoryAxis xAxis = new CategoryAxis();
		xAxis.setCategories(FXCollections.<String>observableArrayList(
				Arrays.asList("2", "4", "6", "8", "10", "12", "14", "16", "18",
						"20", "22", "24", "26", "28", "30", "32", "34", "36",
						"38", "40")));
		xAxis.setLabel("Number Rolled");
		
		NumberAxis yAxis = new NumberAxis();
		yAxis.setAutoRanging(false);
		yAxis.setTickUnit(2);
		yAxis.setLowerBound(0);
		yAxis.setUpperBound(20);
		yAxis.setLabel("Total rolled");
		
		BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
		barChart.setTitle("Probability Totals for all Possible Rolls");
		
		barChart.setBarGap(9);
		barChart.setCategoryGap(1);
		
		XYChart.Series<String, Number> series1 = new XYChart.Series<>();		series1.setName("1");
		XYChart.Series<String, Number> series2 = new XYChart.Series<>();		series2.setName("2");
		XYChart.Series<String, Number> series3 = new XYChart.Series<>();		series3.setName("3");
		XYChart.Series<String, Number> series4 = new XYChart.Series<>();		series4.setName("4");
		XYChart.Series<String, Number> series5 = new XYChart.Series<>();		series5.setName("5");
		XYChart.Series<String, Number> series6 = new XYChart.Series<>();		series6.setName("6");
		XYChart.Series<String, Number> series7 = new XYChart.Series<>();		series7.setName("7");
		XYChart.Series<String, Number> series8 = new XYChart.Series<>();		series8.setName("8");
		XYChart.Series<String, Number> series9 = new XYChart.Series<>();		series9.setName("9");
		XYChart.Series<String, Number> series10 = new XYChart.Series<>();		series10.setName("10");
		XYChart.Series<String, Number> series11 = new XYChart.Series<>();		series11.setName("11");
		XYChart.Series<String, Number> series12 = new XYChart.Series<>();		series12.setName("12");
		XYChart.Series<String, Number> series13 = new XYChart.Series<>();		series13.setName("13");
		XYChart.Series<String, Number> series14 = new XYChart.Series<>();		series14.setName("14");
		XYChart.Series<String, Number> series15 = new XYChart.Series<>();		series15.setName("15");
		XYChart.Series<String, Number> series16 = new XYChart.Series<>();		series16.setName("16");
		XYChart.Series<String, Number> series17 = new XYChart.Series<>();		series17.setName("17");
		XYChart.Series<String, Number> series18 = new XYChart.Series<>();		series18.setName("18");
		XYChart.Series<String, Number> series19 = new XYChart.Series<>();		series19.setName("19");
		XYChart.Series<String, Number> series20 = new XYChart.Series<>();		series20.setName("20");
		
		XYChart.Series<String, Number> series21 = new XYChart.Series<>();		series21.setName("21");
		XYChart.Series<String, Number> series22 = new XYChart.Series<>();		series22.setName("22");
		XYChart.Series<String, Number> series23 = new XYChart.Series<>();		series23.setName("23");
		XYChart.Series<String, Number> series24 = new XYChart.Series<>();		series24.setName("24");
		XYChart.Series<String, Number> series25 = new XYChart.Series<>();		series25.setName("25");
		XYChart.Series<String, Number> series26 = new XYChart.Series<>();		series26.setName("26");
		XYChart.Series<String, Number> series27 = new XYChart.Series<>();		series27.setName("27");
		XYChart.Series<String, Number> series28 = new XYChart.Series<>();		series28.setName("28");
		XYChart.Series<String, Number> series29 = new XYChart.Series<>();		series29.setName("29");
		XYChart.Series<String, Number> series30 = new XYChart.Series<>();		series30.setName("30");
		XYChart.Series<String, Number> series31 = new XYChart.Series<>();		series31.setName("31");
		XYChart.Series<String, Number> series32 = new XYChart.Series<>();		series32.setName("32");
		XYChart.Series<String, Number> series33 = new XYChart.Series<>();		series33.setName("33");
		XYChart.Series<String, Number> series34 = new XYChart.Series<>();		series34.setName("34");
		XYChart.Series<String, Number> series35 = new XYChart.Series<>();		series35.setName("35");
		XYChart.Series<String, Number> series36 = new XYChart.Series<>();		series36.setName("36");
		XYChart.Series<String, Number> series37 = new XYChart.Series<>();		series37.setName("37");
		XYChart.Series<String, Number> series38 = new XYChart.Series<>();		series38.setName("38");
		XYChart.Series<String, Number> series39 = new XYChart.Series<>();		series39.setName("39");
		XYChart.Series<String, Number> series40 = new XYChart.Series<>();		series40.setName("40");

				
		
		barChart.getData().addAll(series1, series2, series3, series4, series5,
								series6, series7, series8, series9, series10,
								series11, series12, series13, series14, series15,
								series16, series17, series18, series19, series20,
								series21, series22, series23, series24, series25,
								series26, series27, series28, series29, series30,
								series31, series32, series33, series34, series35,
								series36, series37, series38, series39, series40);
		
		
		pane2.getChildren().add(barChart);

	//Stage show
		primaryStage.setTitle("Probability Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	//Unbounded Text and lines for tab1
		Text text1 = new Text(30, 20, "Choose the first probability object");
		Text text2 = new Text(285, 20, "Choose the second probability object");
		Line line = new Line(254, 10, 254, 125);	line.setStrokeWidth(3);
		
	//Unbounded Text and Lines for tab2
		
	//TextAreas and associated ScrollPanes
		TextArea Results = new TextArea();		ScrollPane scrollPane = new ScrollPane(Results);
		Results.setWrapText(true);				scrollPane.setLayoutX(0);
		Results.setEditable(false);				scrollPane.setLayoutY(200);
		
	//Hboxes
		HBox compare1pane = new HBox(25);
		HBox compare2pane = new HBox(19);
		HBox compare3pane = new HBox(15);
	
	//group1
		//RadioButtons
		RadioButton d2 = new RadioButton("d2");
		RadioButton d4 = new RadioButton("d4");
		RadioButton d6 = new RadioButton("d6");
		RadioButton d8 = new RadioButton("d8");
		RadioButton d10 = new RadioButton("d10");
		RadioButton d12 = new RadioButton("d12");
		RadioButton d20 = new RadioButton("d20");
		RadioButton c52 = new RadioButton("52c");
		RadioButton custom1 = new RadioButton("Custom");
		
		//ToggleGroup, Id's, and custom1
		ToggleGroup group1 = new ToggleGroup();
		d2.setToggleGroup(group1);			d2.setId("2");
		d4.setToggleGroup(group1);			d4.setId("4");
		d6.setToggleGroup(group1);			d6.setId("6");
		d8.setToggleGroup(group1);			d8.setId("8");
		d10.setToggleGroup(group1);			d10.setId("10");
		d12.setToggleGroup(group1);			d12.setId("12");
		d20.setToggleGroup(group1);			d20.setId("20");
		c52.setToggleGroup(group1);			c52.setId("52");
		custom1.setToggleGroup(group1);		//custom1 id set in calculate
		
		TextField custom1Side = new TextField("Enter Sides");
		custom1Side.setEditable(false);
		custom1.setOnAction(e -> custom1Side.setEditable(true));
		
	//group2
		//RadioButtons
		RadioButton d2v2 = new RadioButton("d2");
		RadioButton d4v2 = new RadioButton("d4");
		RadioButton d6v2 = new RadioButton("d6");
		RadioButton d8v2 = new RadioButton("d8");
		RadioButton d10v2 = new RadioButton("d10");
		RadioButton d12v2 = new RadioButton("d12");
		RadioButton d20v2 = new RadioButton("d20");
		RadioButton c52v2 = new RadioButton("52c");
		RadioButton custom2 = new RadioButton("Custom");
		
		//ToggleGroup, Id's, and custom2
		ToggleGroup group2 = new ToggleGroup();
		d2v2.setToggleGroup(group2);		d2v2.setId("2");
		d4v2.setToggleGroup(group2);		d4v2.setId("4");
		d6v2.setToggleGroup(group2);		d6v2.setId("6");
		d8v2.setToggleGroup(group2);		d8v2.setId("8");
		d10v2.setToggleGroup(group2);		d10v2.setId("10");
		d12v2.setToggleGroup(group2);		d12v2.setId("12");
		d20v2.setToggleGroup(group2);		d20v2.setId("20");
		c52v2.setToggleGroup(group2);		c52v2.setId("51");
		custom2.setToggleGroup(group2);		//custom2 id set in calculate
		
		TextField custom2Side = new TextField("Enter Sides");
		custom2Side.setEditable(false);
		custom2.setOnAction(e -> custom2Side.setEditable(true));
		
	//Compare HBox panes
		compare1pane.getChildren().addAll(d2, d4, d6, d8,d2v2, d4v2, d6v2, d8v2);
		compare1pane.setLayoutX(5);
		compare1pane.setLayoutY(35);
		
		compare2pane.getChildren().addAll( d10, d12, d20, c52, d10v2, d12v2, d20v2, c52v2);
		compare2pane.setLayoutX(5);
		compare2pane.setLayoutY(65);
		
		compare3pane.getChildren().addAll(custom1, custom1Side, custom2, custom2Side);
		compare3pane.setLayoutX(5);
		compare3pane.setLayoutY(95);
		
	//Buttons and actions
		Button exit = new Button("Exit");
		exit.setLayoutX(96);
		exit.setLayoutY(148);
		exit.setOnAction(e -> System.exit(0));

		
		Button help = new Button("Help");
		help.setLayoutX(376);
		help.setLayoutY(148);
		String helpText = "This is a Probability calculator using dice and cards.\n"
				+ "The dice are represented with the d letter and the number\n"
				+ "of sides coming after the letter d in the options above.\n"
				+ "The Cards are represented with the 52c, the letter c meaning\n"
				+ "cards. Comparing dice with a custom number of sides are user\n"
				+ "entered into the text field to the right of the custom bubble\n"
				+ "The custom bubble must be selected to edit the number of sides\n\n"
				+ "How to use this calculator\n"
				+ "click on a die or card in the upper left side of the window and\n"
				+ "compare it with the second object once the calculate button is\n"
				+ "pressed\n"
				+ "This will give results in this text area where the help button\n"
				+ "shows this help text currently.\n"
				+ "The results will show the die number rolled or card drawn for both\n"
				+ "objects, the probability percentage of that number rolled or drawn\n"
				+ "for both objects, the max number probable for both objects, the\n"
				+ "total of both object numbers added together, the times that the total\n"
				+ "can be rolled out of the possible rolls, and the probability of the\n"
				+ "total to be rolled divided by all of the possible rolls to get the\n"
				+ "percent chance of the total to be rolled between the two objects.\n"
				+ "The text area will also display all possible rolls after the results\n"
				+ "are shown. If comparing cards this text area will not display all\n"
				+ "possible cards drawn because the data would be too large for the\n"
				+ "text area.\n"
				+ "In the upper left hand corner of the window there is a Calculate\n"
				+ "and a Graph tab. Objects must be compared using the calculate\n"
				+ "button in order for the graph to display relative data for the\n"
				+ "objects compared. This will only display dice numbers that are\n"
				+ "below 21 sides. If the user would like to see the full set of\n"
				+ "graph data they would limit their die sides to 20 or below for\n"
				+ "both dice. The graph will not show a graph for card comparisons,\n"
				+ "this would be too big of a data set to be represented in the\n"
				+ "graph\n\n"
				+ "Clicking on the Exit button will close the program.";
		help.setOnAction(e -> Results.setText(helpText));

		
		Button calculate = new Button("Calculate");
		calculate.setLayoutX(219);
		calculate.setLayoutY(148);
		
	//Button Calculate acton
		calculate.setOnAction(c -> {
			
			//Id's are set to gather if applicable
			custom1.setId(custom1Side.getText());
			custom2.setId(custom2Side.getText());
			

			String textIn = "Here are your results\n";
			String textIn1 = "";
			String textIn2 = "";
			String gridText = "\nHere is all of the possible rolls\n";

			String textFinal = "";
			
			int input1;
			int input2;

			try {
			
			Toggle identify1 = group1.getSelectedToggle();
			input1 = Integer.valueOf(((Node) identify1).getId());
			
			Toggle identify2 = group2.getSelectedToggle();
			input2 = Integer.valueOf(((Node) identify2).getId());
			
			
	//added and modified old code start
			
			int[] n = new int[2];	 // used to store both numbers that are rolled or drawn
			int[] g = new int[2];	 // used to store user inputs
			
			
			int newUserIn = 0;		 // user input
			int newUser = 0;		 // this is passed to most methods
			int totalDice = 0;		 // this equals the max of both dice
			int totalRoll = 0;		 // this equals the max of dice rolled
			int cardsComp = 0;		 // this is used for comparing two cards
			double times = 0;		 // this counts the number of times a number can be rolled on two dice 
			double totalPoss = 0.0;	 // this is used to calculate the total possibility of two dice
			double percentage = 0.0; // this is used to calculate the percentage (times / totalDice)
			
			
			// This stored Obj and Obj2, which are Probability and Probability2 respectively
			ArrayList<Object> list = new ArrayList<>();
			
			//intro

			for (int i = 0; i < 1; i++) {
				
		//First comparable object
				
			//Saving input and storing values
			newUserIn = input1;
			newUser = newUserIn;
			g[0] = newUser;
			n[1] = 21;
			
			if (g[0] == 52) {
				cardsComp = 1;
			}
			
			//Create first object
				Probability Probability = new Probability();
				Probability.getDieNumber(
						Probability.setDice(
							Probability.setUserInput(
								Probability.getUserInput(newUser))));
				
				Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
				Probability.getCardType();
				Probability.getCardSuit();
					list.add(Probability);
					n[0] = Probability.roll;
					
				

	//Second object to compare
				
			//Saving input and storing values
				newUserIn = input2;
				newUser = newUserIn;
				g[1] = newUser;
			
			
		//Create second object
			Probability Probability2 = new Probability();
			Probability2.getDieNumber(
					Probability2.setDice(
						Probability2.setUserInput(
							Probability2.getUserInput(newUser))));
				
				Probability2.getMax(Probability2.setUserInput(Probability2.getUserInput(newUser)));
				Probability2.getIterate(cardsComp);
				list.add(Probability2);
				n[1] = Probability2.roll;
				
		//redo randomizer if the card from the second object equals the card from the first object
				if (newUser == 52 && n[0] == n[1] && Probability2.cardType == Probability.cardType) {
					Probability2.getDieNumber(
						Probability2.setDice(
							Probability2.setUserInput(
								Probability2.getUserInput(newUser))));
					
					Probability.getMax(Probability.setUserInput(Probability.getUserInput(newUser)));
					Probability2.getIterate(cardsComp);
					Probability2.getCardType();
					Probability2.getCardSuit();
						n[1] = Probability2.roll;
					}//else if end
				
			}//for loop end
		
		//Storing objects into the array
			Probability Obj = (Probability)list.get(0);
			Probability Obj2 = (Probability)list.get(1);

			

			/* This code was used for testing purposes
			 *  
			System.out.println(Obj2.iterative);

			System.out.println("\nThese are user inputs " + g[0] + " " + g[1]);
			System.out.println("These are number outcomes " + n[0] + " " + n[1]);
			
			if(g[0] == 8 || g[1] == 8) {
			System.out.println("These are the card types " + Obj.cardType + " " + Obj2.cardType);
			}
			*/
			
		//compare display code
			
			
		//dice comparing printed in the Text Area
			for(int r = 0; r < 2; r++) {
				if(0 < g[r] && g[r] < 21) {
					if (r == 0) {
					newUser = g[r];
					textIn1 = "You rolled a d" + (Obj.dieChosen.length) + " and got a " + (Obj.roll);
					textIn = textIn.concat(textIn1);
					}//if end

					else {
						newUser = g[r];
						textIn2 = "          You rolled a d" + (Obj2.dieChosen.length) + " and got a " + (Obj2.roll) + "\n";
						textIn = textIn.concat(textIn2);
						}//else end
				}//if end
				
		//card comparing printed in the Text Area
				else {
					if (r == 0) {
						newUser = g[r];
						textIn1 = "You drew a " + Obj.royals(n[r]) + " of " + Obj.getCardSuit();
						textIn = textIn.concat(textIn1);
					}
					else {
						newUser = g[r];
						textIn2 = "          You drew a " + Obj2.royals(n[r]) + " of " + Obj2.getCardSuit() + "\n";
						textIn = textIn.concat(textIn2);
					}
				}//else end
				
			}//for loop end
			
			//System.out.println("This is the max " + Obj.max  + " " + Obj2.max); this was used for testing purposes
			
		//running important method before code percentage calculations
			Obj2.getProbability();
			
		//comparing two dice
			if(Obj.max < 50 && Obj2.max < 50) {
				totalDice = (int)Obj.max + (int)Obj2.max;
				totalPoss = (int)Obj.max * (int)Obj2.max;
				totalRoll = Obj.roll + Obj2.roll;
				for(int o = 0; o < Obj.dieChosen.length; o++) {
					for (int p = 0; p < Obj2.dieChosen.length; p++) {
						if(totalRoll == Obj.dieChosen[o] + Obj2.dieChosen[p]) {
							times++;
						}
					}//Obj2 counting for loop end
				}//Obj counting for loop end
				textIn1 = String.format("The probability of the first object is %2.3f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				percentage = times / totalDice;
				textIn1 = "The max that can be rolled is " + (int)(Obj.max + Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				
				textIn1 = "The total of " + totalRoll + " can be rolled " + (int)times + " times out of " + (int)totalPoss + " possible rolls\n";
				textIn = textIn.concat(textIn1);
							
				textIn1 = String.format((int)times + " divided by " + (int)totalPoss + " equals a %2.1f percent chance \n", ((times / totalPoss) * 100));
				textIn = textIn.concat(textIn1);
			}//if end
			
		//comparing two cards
			else if(Obj.max == 52 && Obj2.max == 51) {
				textIn1 = "The max number of cards that can be drawn is " + (int)(Obj.max) + "\n";
				textIn = textIn.concat(textIn1);
				
				textIn1 = String.format("The probability of the first object is %2.4f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.4f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The total chance of drawing these cards is a %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
		
		//comparing a card and a die
			else if(Obj.max == 52 && Obj2.max < 50){
				textIn1 = "The max number of cards that can be drawn is " + (int)(Obj.max) + "\n";
				textIn2 = "The max that can be rolled is " + (int)(Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The probability of the first object is %2.4f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.3f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);

				textIn1 = String.format("The total chance of drawing a card and rolling a die is %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
			
		//comparing a die and a card
			else {
				textIn1 = "The max that can be rolled is " + (int)(Obj.max) + "\n";
				textIn2 = "The max number of cards that can be drawn is " + (int)(Obj2.max) + "\n";
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);
				
				textIn1 = String.format("The probability of the first object is %2.3f \n", (Obj.getProbability()));
				textIn2 = String.format("The probability of the second object is %2.4f \n", (Obj2.getProbability()));
				textIn = textIn.concat(textIn1);
				textIn = textIn.concat(textIn2);

				textIn1 = String.format("The total chance of rolling a die and drawing a card is %2.1f percent chance \n", (((2 / (Obj.max + Obj2.max)) * 100)));
				textIn = textIn.concat(textIn1);
			}
			
		//final, display and input code
			textIn1 = "\nWould you like to compare two more objects?" + "\n";
			textIn2 = "Choose two more objects and click the calculate button";
			
			
		//used for testing purposes to make sure nothing else is printed in the terminal
			System.out.println("Thank you for trying out my probability calculator.\n");
			

	//modified Old code end
			
			textFinal = textIn;
			
			setResults(Results, textFinal);
			
	//GridText found in the text area
			int gridLength;
			int gridHeight;
			int[][] matrix;
			
			if(input1 > input2) {
				gridLength = (int)Obj.max;
				gridHeight = (int)Obj2.max;	
				
			} //if end
			
			else if(input1 < input2) {
				gridLength = (int)Obj2.max;
				gridHeight = (int)Obj.max;

			} //else if end
			
			else {
				gridLength = (int)Obj.max;
				gridHeight = (int)Obj2.max;
			} //else end
			
			
			
			String gridLine = "\n";
			String gridSpace = "  ";
			String gridTexting = "";
			
		//chart variables used to create the charted probability
			Integer chartNum = 0;
			
			Integer chartCount1 = 0;		Integer chartCount2 = 0;
			Integer chartCount3 = 0;		Integer chartCount4 = 0;
			Integer chartCount5 = 0;		Integer chartCount6 = 0;
			Integer chartCount7 = 0;		Integer chartCount8 = 0;
			Integer chartCount9 = 0;		Integer chartCount10 = 0;
			Integer chartCount11 = 0;		Integer chartCount12 = 0;
			Integer chartCount13 = 0;		Integer chartCount14 = 0;
			Integer chartCount15 = 0;		Integer chartCount16 = 0;
			Integer chartCount17 = 0;		Integer chartCount18 = 0;
			Integer chartCount19 = 0;		Integer chartCount20 = 0;
			Integer chartCount21 = 0;		Integer chartCount22 = 0;
			Integer chartCount23 = 0;		Integer chartCount24 = 0;
			Integer chartCount25 = 0;		Integer chartCount26 = 0;
			Integer chartCount27 = 0;		Integer chartCount28 = 0;
			Integer chartCount29 = 0;		Integer chartCount30 = 0;
			Integer chartCount31 = 0;		Integer chartCount32 = 0;
			Integer chartCount33 = 0;		Integer chartCount34 = 0;
			Integer chartCount35 = 0;		Integer chartCount36 = 0;
			Integer chartCount37 = 0;		Integer chartCount38 = 0;
			Integer chartCount39 = 0;		Integer chartCount40 = 0;


			
			if(gridLength > 20 || gridHeight > 20) {
				gridText = "\nPlease pick a dice object to show the grid probability pairings"
						+ "\nThe grid for cards or a die size larger than 20 is too big for this text area\n";
			}//if end
			
			else {
			
			matrix = new int[gridHeight][gridLength]; //initializing matrix

			//I got the matrix to print mostly how I would like it to be.
			
			for (int row = 0; row < matrix.length; row++) {
				for (int column = 0; column < matrix[row].length; column++) {
					chartNum = 0;

					gridTexting = String.format((row + 1) + "/" + (column + 1));
					gridText = gridText.concat(gridTexting);
					gridText = gridText.concat(gridSpace);
					
					chartNum = ((row + 1) + (column + 1));
					
					if(chartNum == 1) {chartCount1++;}
					else if(chartNum == 2) {chartCount2++;}
					else if(chartNum == 3) {chartCount3++;}
					else if(chartNum == 4) {chartCount4++;}
					else if(chartNum == 5) {chartCount5++;}
					else if(chartNum == 6) {chartCount6++;}
					else if(chartNum == 7) {chartCount7++;}
					else if(chartNum == 8) {chartCount8++;}
					else if(chartNum == 9) {chartCount9++;}
					else if(chartNum == 10) {chartCount10++;}
					else if(chartNum == 11) {chartCount11++;}
					else if(chartNum == 12) {chartCount12++;}
					else if(chartNum == 13) {chartCount13++;}
					else if(chartNum == 14) {chartCount14++;}
					else if(chartNum == 15) {chartCount15++;}
					else if(chartNum == 16) {chartCount16++;}
					else if(chartNum == 17) {chartCount17++;}
					else if(chartNum == 18) {chartCount18++;}
					else if(chartNum == 19) {chartCount19++;}
					else if(chartNum == 20) {chartCount20++;}
					else if(chartNum == 21) {chartCount21++;}
					else if(chartNum == 22) {chartCount22++;}
					else if(chartNum == 23) {chartCount23++;}
					else if(chartNum == 24) {chartCount24++;}
					else if(chartNum == 25) {chartCount25++;}
					else if(chartNum == 26) {chartCount26++;}
					else if(chartNum == 27) {chartCount27++;}
					else if(chartNum == 28) {chartCount28++;}
					else if(chartNum == 29) {chartCount29++;}
					else if(chartNum == 30) {chartCount30++;}
					else if(chartNum == 31) {chartCount31++;}
					else if(chartNum == 32) {chartCount32++;}
					else if(chartNum == 33) {chartCount33++;}
					else if(chartNum == 34) {chartCount34++;}
					else if(chartNum == 35) {chartCount35++;}
					else if(chartNum == 36) {chartCount36++;}
					else if(chartNum == 37) {chartCount37++;}
					else if(chartNum == 38) {chartCount38++;}
					else if(chartNum == 39) {chartCount39++;}
					else if(chartNum == 40) {chartCount40++;}
					
					else {}
					
				
				}//for loop end

				gridText = gridText.concat(gridLine);
			}//for loop end
			
	//adding data to the chart
			series1.getData().add(new XYChart.Data<>("2", chartCount1));
			series2.getData().add(new XYChart.Data<>("2", chartCount2));
			series3.getData().add(new XYChart.Data<>("4", chartCount3));
			series4.getData().add(new XYChart.Data<>("4", chartCount4));
			series5.getData().add(new XYChart.Data<>("6", chartCount5));
			series6.getData().add(new XYChart.Data<>("6", chartCount6));
			series7.getData().add(new XYChart.Data<>("8", chartCount7));
			series8.getData().add(new XYChart.Data<>("8", chartCount8));
			series9.getData().add(new XYChart.Data<>("10", chartCount9));
			series10.getData().add(new XYChart.Data<>("10", chartCount10));
			series11.getData().add(new XYChart.Data<>("12", chartCount11));
			series12.getData().add(new XYChart.Data<>("12", chartCount12));
			series13.getData().add(new XYChart.Data<>("14", chartCount13));
			series14.getData().add(new XYChart.Data<>("14", chartCount14));
			series15.getData().add(new XYChart.Data<>("16", chartCount15));
			series16.getData().add(new XYChart.Data<>("16", chartCount16));
			series17.getData().add(new XYChart.Data<>("18", chartCount17));
			series18.getData().add(new XYChart.Data<>("18", chartCount18));
			series19.getData().add(new XYChart.Data<>("20", chartCount19));
			series20.getData().add(new XYChart.Data<>("20", chartCount20));
			
			series21.getData().add(new XYChart.Data<>("22", chartCount21));
			series22.getData().add(new XYChart.Data<>("22", chartCount22));
			series23.getData().add(new XYChart.Data<>("24", chartCount23));
			series24.getData().add(new XYChart.Data<>("24", chartCount24));
			series25.getData().add(new XYChart.Data<>("26", chartCount25));
			series26.getData().add(new XYChart.Data<>("26", chartCount26));
			series27.getData().add(new XYChart.Data<>("28", chartCount27));
			series28.getData().add(new XYChart.Data<>("28", chartCount28));
			series29.getData().add(new XYChart.Data<>("30", chartCount29));
			series30.getData().add(new XYChart.Data<>("30", chartCount30));
			series31.getData().add(new XYChart.Data<>("32", chartCount31));
			series32.getData().add(new XYChart.Data<>("32", chartCount32));
			series33.getData().add(new XYChart.Data<>("34", chartCount33));
			series34.getData().add(new XYChart.Data<>("34", chartCount34));
			series35.getData().add(new XYChart.Data<>("36", chartCount35));
			series36.getData().add(new XYChart.Data<>("36", chartCount36));
			series37.getData().add(new XYChart.Data<>("38", chartCount37));
			series38.getData().add(new XYChart.Data<>("38", chartCount38));
			series39.getData().add(new XYChart.Data<>("40", chartCount39));
			series40.getData().add(new XYChart.Data<>("40", chartCount40));


			
			gridText = gridText.concat(gridLine);
			
			
			} //else end
			
						
			} //try end
			
			catch(NullPointerException ex) {
				textIn = "Please choose Probability Objects to compare\n";
				textFinal = textIn;
				setResults(Results, textFinal);
				throw ex;
			}//catch end
			
			finally {
			textIn = textIn.concat(gridText);
			textIn = textIn.concat(textIn1);
			textIn = textIn.concat(textIn2);
			textFinal = textIn;
			setResults(Results, textFinal);
			}
		});//calculate action end
		
	//Adding all panes, buttons, HBoxes, Lines and Text into Pane pane
		pane.getChildren().addAll(compare1pane, calculate, compare2pane,
				compare3pane, text1, text2, scrollPane, line, exit, help);
		
	}//method start end

	private void setResults(TextArea Results, String textFinal) {
		Results.setText(textFinal);
	}//method setResults end

}//Class ProbabilityTest end
