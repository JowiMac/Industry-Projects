/* John Macdonald
 * Feb. 2, 2023
 * 
 * This code creates a server and
 * helps the client compute payments
 * 
 * I modified this code.
 * */

package exercise33_01;
import java.net.ServerSocket;
// Exercise31_01Server.java: The server can communicate with
// multiple clients concurrently using the multiple threads
import java.util.*;
import java.io.*;
import java.net.*;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class Exercise33_01Server extends Application {
  // Text area for displaying contents
  private TextArea ta = new TextArea();


  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    ta.setWrapText(true);

    //initial starting date created
    
    new Thread(() -> {
    	try {
    	ServerSocket serverSocket = new ServerSocket(8000);
    	Platform.runLater(() -> ta.setText("Exercise31_01Server started at " + new Date() + '\n'));
    
    
    Socket socket = serverSocket.accept();
    ta.appendText("Connected to a client at " + new Date() + '\n');
    	
    	DataInputStream ClientInput = new DataInputStream(socket.getInputStream());
    	DataOutputStream ClientOutput = new DataOutputStream(socket.getOutputStream());
    	
    	while(true) {
    		Double annualInterestRate = ClientInput.readDouble();
    		    ta.appendText("Annual Interest Rate: " + annualInterestRate + '\n');

    		Integer numberOfYears = ClientInput.readInt();
    			ta.appendText("Number of Years: " + numberOfYears + '\n');
    			
    		Double loanAmount = ClientInput.readDouble();
    			ta.appendText("Loan Amount: " + loanAmount + '\n');
    		
    		Double monthlyPayment = ClientInput.readDouble();
    			ta.appendText("Monthly Payment: " + monthlyPayment + '\n');
    			
    		Double totalPayment = ClientInput.readDouble();
    			ta.appendText("Total Payment: " + totalPayment + '\n');
    			
    			
    		
    	}//while end
    	}//try end
    	
    	catch(IOException ex) {
    		ex.printStackTrace();
    	}//catch end
    	
    	}).start();//Thread end
    
    

    // Create a scene and place it in the stage
    Scene scene = new Scene(new ScrollPane(ta), 400, 200);
    primaryStage.setTitle("Exercise31_01Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }
    
  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    launch(args);
  }
}
